import { useState } from "react"

function UseCounter() {

    const [count, setCount] = useState(0)

    function inc() {
        setCount(count + 1)
    }

    function dec() {
        setCount(count - 1)
    }

    function res() {
        setCount(0)
    }

    return [count,inc,dec,res]
}

export default UseCounter;