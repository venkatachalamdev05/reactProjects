import React from "react"
import Login from "./Login.js";

const Mylist = (props) => {
  return (
    <>
      <p>My List Comp</p>
      <Login></Login>
    </>
  )
};

export default Mylist;
