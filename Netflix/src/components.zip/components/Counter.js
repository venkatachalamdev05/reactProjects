import React from "react"
import UseCounter from "./useCounter";

const Counter = (props) => {


    const [count,inc,dec,res] = UseCounter();
    return (
        <div>

            <button className="btn btn-danger" onClick={inc}>
                +
            </button><br></br>
            {count}<br></br>
            <button className="btn btn-danger" onClick={dec}>
                -
            </button><br></br>
            <button className="btn btn-danger" onClick={res}>
                Reset
            </button><br></br>
        </div>
    )
};

export default Counter;
